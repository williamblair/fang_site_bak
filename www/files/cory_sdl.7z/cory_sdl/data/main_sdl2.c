#include <stdio.h>
#include <stdlib.h>
#include <time.h>   // needed for srand(time(0))

#include <SDL.h>            // the main Simple Direct Medialayer library
#include <SDL2/SDL_image.h> // the SDL image library
#include <SDL_mixer.h>      // tbe SDL audio library

#undef main

int main(int argc, char *argv[])
{
  int winPosX = 0;
  int winPosY = 0;

  SDL_Window *window = NULL;        // holds the window
  SDL_Surface *winSurface = NULL;   // holds the image surface of the window
  SDL_Surface *cory = NULL;         // holds the cory image

  Mix_Music *coryTheme = NULL;

  // init main
  if(SDL_Init(SDL_INIT_EVERYTHING) < 0)
  {
    printf("Error initializing Cory!\n");
    return -1;
  }

  // init images
  if(IMG_Init(IMG_INIT_JPG) < 0)
  {
    printf("Error initializing Cory image!\n");
    return -1;
  }

  // init audio
  if(Mix_Init(MIX_INIT_MP3) < 0)
  {
	  printf("Error initializing Cory theme!\n");
	  return -1;
  }

  // init the sound channel on the computer
  if( Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 2, 2048) < 0 )
  {
	  printf("Error opening audio!\n");
	  return -1;
  }

  coryTheme = Mix_LoadMUS("cory_theme.mp3");
  if(!coryTheme) // if the mp3 wasn't loaded
  {
	  printf("Error opening Cory beats!\n");
	  return -1;
  }

  Mix_PlayMusic(coryTheme, -1); // start playing the music, -1 means loop

  cory = IMG_Load("coryis.jpeg");
  if(!cory) // if the cory image wasn't loaded
  {
    printf("Cory is NOT in the house or on your computer!\n");
    return -1;
  }

  srand(time(0)); // seed random

  winPosX = rand()%1360; // make the x position be between 0 and 1360
  winPosY = rand()%768;  // make the y position be between 0 and 768

  // creates a window at the random location above
  window = SDL_CreateWindow("CoryCoryCoryCoryCory", winPosX, winPosY,
                             640, 480, SDL_WINDOW_SHOWN );

  if(!window) // if the window failed to be created
  {
    printf("Error creating Cory window!\n");
    return -1;
  }

  winSurface = SDL_GetWindowSurface(window);

  int quit = 0;
  SDL_Event event; // holds the quit event
  while(!quit) // loop until quit = 1, never happens
  {
    while(SDL_PollEvent(&event)) // gets events like keyboard presses, mouse clicks, exits, etc.
    {
      if(event.type == SDL_QUIT) // if the exit button is clicked or alt+f4 or something like that
      {
        system("start /B main_sdl2.exe"); // run this program again twice
        SDL_Delay(100);                   // wait 100 milliseconds
        system("start /B main_sdl2.exe");
      }
    }


      SDL_BlitSurface(cory, NULL, winSurface, NULL); // add the image to the window

      SDL_UpdateWindowSurface(window); // refresh the window

      SDL_Delay(1000/30.0); // make Cory run 30 FPS
  }

  // close everything
  SDL_DestroyWindow(window);
  Mix_FreeMusic(coryTheme);
  Mix_Quit();
  IMG_Quit();
  SDL_Quit();
  return 0;
}
