
#include <iostream>
#include "setbgapp.h"

SetBGApp::SetBGApp(int argc, char *argv[])
: setbg_button("Set Background"), // create button with label
	addir_button("Add Directory"),
	quit_button("Quit"),
	vbox(Gtk::ORIENTATION_VERTICAL, 0), // create a vbox
	hbox_b(Gtk::ORIENTATION_HORIZONTAL, 0), // create hbox for bottom row
	hbox_r(Gtk::ORIENTATION_HORIZONTAL, 0), //  hbox for options row
	file_counter(0), // set file_counter to 0
	rbf("Fullscreen"),
	rbc("Centered"),
	rbt("Tiled"),
	rba("Aspect")
{
///////////////////////////////////////////////////////////
//               SET WIDGET PROPERTIES                   //
///////////////////////////////////////////////////////////
	/* set border width */
	/* window.set_border_width*/
	set_border_width(10);

	/* TESTING - set default size */
	set_default_size(400, 400);

	/* initialize scrolled window */
	sw.set_border_width(10);

	/* tell gtk to always show the scroll bars */
	/* first arg - horizontal scrollbar,
	 * second arg - vertical scrollbar */
	sw.set_policy(Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);

	/* make the button not expand */
//	setbg_button.set_hexpand(false);
//	setbg_button.set_vexpand(false);


	/* make the radio buttons part of the same group */
	Gtk::RadioButton::Group group = rbf.get_group();
	rbc.set_group(group);
	rbt.set_group(group);
	rba.set_group(group);

///////////////////////////////////////////////////////////

	/* Initialize the image list */
	fileListStore = Gtk::ListStore::create(imc);


	/* test directory scanning */
	if( argc == 2 ){
		/* scan the supplied directory for images */
		readDir(argv[1]);
	}

	std::cout << "DEBUG: Out of if argc is 2!\n";

	/* add the image list to the icon view */
	iv.set_model(fileListStore);
//	iv.set_markup_column(imc.filename);
	iv.set_pixbuf_column(imc.thumbnail);

///////////////////////////////////////////////////////////
//               CONNECT SIGNALS                         //
///////////////////////////////////////////////////////////

	/* SIGNAL FUNCTIONS REFERENCED HERE ARE LOCATED IN 
	 * signals.cpp
	 *
	 * */

	setbg_button.signal_clicked().connect(sigc::mem_fun(*this,
	                           &SetBGApp::setbg_button_clicked));

	addir_button.signal_clicked().connect(sigc::mem_fun(*this,
				                     &SetBGApp::addir_button_clicked));

	quit_button.signal_clicked().connect(sigc::mem_fun(*this,
				                     &SetBGApp::close));


	/* icon view signal */
	iv.signal_item_activated().connect(sigc::mem_fun(*this,
	                                   &SetBGApp::iconview_item_activated));

	/* radio button signals */
	rbf.signal_toggled().connect(sigc::mem_fun(*this,
	                             &SetBGApp::rbf_clicked));
	rbc.signal_toggled().connect(sigc::mem_fun(*this,
	                             &SetBGApp::rbc_clicked));
	rbt.signal_toggled().connect(sigc::mem_fun(*this,
	                             &SetBGApp::rbt_clicked));
	rba.signal_toggled().connect(sigc::mem_fun(*this,
	                             &SetBGApp::rba_clicked));

///////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////
//                  PACK WIDGETS                         //
///////////////////////////////////////////////////////////

	/* add stuff to the options row */
	hbox_r.pack_start(rbf, false, false, 0);
	hbox_r.pack_start(rbc, false, false, 0);
	hbox_r.pack_start(rbt, false, false, 0);
	hbox_r.pack_start(rba, false, false, 0);

	/* add stuff to the bottom button row */
	hbox_b.pack_end(setbg_button, false, false, 0);
	hbox_b.pack_end(addir_button, false, false, 0);
	hbox_b.pack_start(quit_button, false, false, 0);

	/* add the icon view to the scroll window */
	sw.add(iv);

	/* add stuff to the vbox */ 
	vbox.pack_start(sw, true, true, 0);
	vbox.pack_start(hbox_r, false, false, 0);
	vbox.pack_start(hbox_b, false, false, 0);

	std::cout << "Packed vbox!\n";

	/* add the vbox to the window */
	/* window.add */
	add(vbox);

	std::cout << "Added vbox!\n";
///////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////
//                  UPDATE WIDGETS                       //
///////////////////////////////////////////////////////////
	/* update the widgets */
	setbg_button.show();
	addir_button.show();
	quit_button.show();
	rbf.show();
	rbc.show();
	rbt.show();
	rba.show();
	hbox_b.show();
	hbox_r.show();
	sw.show();
	iv.show();
	vbox.show();
///////////////////////////////////////////////////////////
	std::cout << "End of constructor!\n";
}

SetBGApp::~SetBGApp(){}

void SetBGApp::AddImageFile(Glib::ustring f)
{
	/* new row and iterator for the gtk file list */
	Gtk::TreeModel::iterator i = fileListStore->append();
	Gtk::TreeModel::Row row = *i;

	/* add the filename to the new 'imc_new' */
	row[imc.filename] = f;

	/* create a Gdk::Pixbuf from the given file name 
	 * the false is wether to preserve image aspect or not
	 * */
	row[imc.thumbnail] = Gdk::Pixbuf::create_from_file(f, ICON_WIDTH, 
	                                                      ICON_HEIGHT,
	                                                      false	);

	file_counter++;

	return;
}

void SetBGApp::printFileList(void)
{
	/* contains all of the fileList's children */
	Gtk::TreeModel::Children children = fileListStore->children();

	/* an iterator through the children object */
	Gtk::TreeModel::Children::iterator iter;

	int i=0; // just to print out the number of files

	/* starts at beginning at list until reaches end */
	for( iter=children.begin(), i=0; iter!=children.end(); ++iter, i++)
	{
		Gtk::TreeModel::Row row = *iter; // access data from the current row

		std::cout << "File Name " << i+1 << ":\t" << row[imc.filename] << std::endl;

	}

	return;
}

